import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const extensionDir = fileURLToPath(new URL('../', import.meta.url));
const result = spawnSync('pnpm', ['exec', 'wxt', 'build', '-b', 'firefox'], {
  cwd: extensionDir,
  env: { ...process.env, NUVX_STORE_BUILD: '1' },
  stdio: 'inherit',
  shell: process.platform === 'win32',
});
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);

const manifest = JSON.parse(readFileSync(join(extensionDir, '.output/firefox-mv3/manifest.json'), 'utf8'));
if (
  manifest.version !== '0.8.0' ||
  manifest.browser_specific_settings?.gecko?.id !== 'extension@nuvx.lol' ||
  manifest.browser_specific_settings?.gecko?.strict_min_version !== '140.0'
) {
  throw new Error('Built manifest does not match the submitted Firefox add-on version 0.8.0.');
}
console.log('Built Firefox 0.8.0 for desktop Firefox 140+.');
