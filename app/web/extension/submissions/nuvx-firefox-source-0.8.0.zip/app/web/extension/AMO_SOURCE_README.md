# Firefox Add-on source and reproducible build (0.8.0)

This is the readable source for the nuvx Firefox add-on version 0.8.0, taken from Git commit f09e6e103a4bb58fe5df393c500f089e5e730576. The add-on's TypeScript, HTML, CSS, manifest configuration and required @nuvx/shared workspace source are included. WXT/Vite generate the installable add-on files during the build; generated bundles are not substituted for source here.

## Build environment

- Windows 10/11, macOS, or Linux, 64-bit x64 or ARM64
- Node.js 22 or newer (npm is included with Node.js)
- pnpm 12.11.2, as pinned in app/web/package.json
- A recent Git 2.x installation to clone the repository
- Desktop Firefox 140 or newer is the target

Install Node.js from https://nodejs.org/ and Git from https://git-scm.com/downloads. In a terminal, install the required pnpm version:

    npm install --global pnpm@12.11.2

## Reproduce the add-on

1. Clone the repository and enter its web workspace:

       git clone https://github.com/bxanedot/nuvx.git
       cd nuvx/app/web

2. Install the exact dependency versions recorded by the lockfile:

       pnpm install --frozen-lockfile

3. Build the Firefox store variant:

       cd extension
       node scripts/build-firefox.mjs

The script enables the store build configuration, builds Firefox with WXT, and checks that the generated manifest is version 0.8.0 with the expected Firefox add-on ID and minimum browser version. Generated files are written to app/web/extension/.output/firefox-mv3/. The store build omits Discord integration as configured in the source.

This source package includes the extension source, required shared workspace source, package manifests, and pnpm lockfile. Generated output and installed dependencies are excluded. Third-party dependencies are restored from the lockfile during reproduction. No private signing key is required or included.
